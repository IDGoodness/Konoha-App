import { useState } from "react";
import { resetPassword } from "../authService";



const ResetPassword = () => {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");

  const handleReset = async () => {
    try {
      await resetPassword(email);
      setMessage("Password reset email sent!");
    } catch (error: any) {
      setMessage(error.message);
    }
  };

  return (
    <div className="p-4 max-w-sm mx-auto">
      <h2 className="text-xl font-bold mb-4">Reset Password</h2>
      <input className="w-full p-2 border mb-2" type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
      <button className="w-full bg-yellow-500 text-white p-2" onClick={handleReset}>Reset Password</button>
      {message && <p className="mt-2 text-sm text-red-500">{message}</p>}
    </div>
  );
};

export default ResetPassword;